import pandas as pd

def backtest(data):
    balance = 100000
    pos_size = 1000
    win, loss = 0, 0
    for i in range(len(data) - 1):
        row = data.iloc[i]
        next_row = data.iloc[i + 1]
        if row["signal"] == "BUY":
            pnl = next_row["close"] - row["close"]
        elif row["signal"] == "SELL":
            pnl = row["close"] - next_row["close"]
        else:
            continue
        balance += pnl * pos_size
        if pnl > 0: win += 1
        else: loss += 1
    winrate = win / (win + loss) * 100 if (win + loss) > 0 else 0
    print(f"Final Balance: ₹{balance:.2f}\nWin Rate: {winrate:.2f}%")
