# OptionsBull AI Trading Bot

This bot includes:
- TradingView-compatible Pine Script indicator
- AI model with orderflow/volume signals
- Auto-retraining scheduler
- Backtester
- Telegram alert system
- Web dashboard for monitoring

## Setup Instructions

1. Install requirements:
```bash
pip install -r requirements.txt
```

2. Train model:
```bash
python orderflow_model.py
```

3. Start dashboard:
```bash
python dashboard/app.py
```

4. Set your Telegram Bot token and chat ID in `config.json`.

5. Backtest:
```bash
python backtest/backtest_engine.py
```
