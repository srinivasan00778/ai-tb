import pandas as pd
import lightgbm as lgb
import pickle
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

df = pd.read_csv("data/historical_data.csv")
df["volatility"] = df["high"] - df["low"]
df["body"] = abs(df["close"] - df["open"])
df["direction"] = (df["close"].shift(-3) > df["close"]).astype(int)

features = ["open", "high", "low", "close", "volume", "volatility", "body"]
X = df[features]
y = df["direction"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, shuffle=False)

model = lgb.LGBMClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
print(f"Validation Accuracy: {accuracy_score(y_test, y_pred):.2f}")

with open("model.pkl", "wb") as f:
    pickle.dump(model, f)
