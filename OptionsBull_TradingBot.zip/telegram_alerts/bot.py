import requests
import json

with open("config.json") as f:
    config = json.load(f)

TOKEN = config["telegram_bot_token"]
CHAT_ID = config["telegram_chat_id"]

def send_alert(message):
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    payload = {"chat_id": CHAT_ID, "text": message}
    requests.post(url, data=payload)
