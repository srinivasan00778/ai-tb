import schedule
import time
import subprocess

def retrain():
    print("Retraining model...")
    subprocess.run(["python", "orderflow_model.py"])

schedule.every().sunday.at("20:00").do(retrain)
while True:
    schedule.run_pending()
    time.sleep(60)
