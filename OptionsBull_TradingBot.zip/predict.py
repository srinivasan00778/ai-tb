import pickle
import pandas as pd

with open("model.pkl", "rb") as f:
    model = pickle.load(f)

def predict_signal(latest_data):
    features = ["open", "high", "low", "close", "volume"]
    df = pd.DataFrame([latest_data])
    df["volatility"] = df["high"] - df["low"]
    df["body"] = abs(df["close"] - df["open"])
    X = df[features + ["volatility", "body"]]
    signal = model.predict(X)[0]
    return "BUY" if signal == 1 else "SELL"
